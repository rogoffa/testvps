#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
umask 077

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [[ ${1:-} == --help || ${1:-} == -h ]]; then
    cat <<'EOF'
Happ VPS: VLESS + REALITY + Vision, Debian 12/13.

  ./start.sh             установка или восстановление своей установки
  ./start.sh --update    обновление Xray до текущего stable с проверкой SHA-256

При первой установке необязательно можно задать VPN_HOST, VPN_PORT,
REALITY_SNI, VPN_NAME через переменные окружения. Домен и TLS-сертификат
покупать не нужно. После установки: sudo happ-vpn help
EOF
    exit 0
fi
if [[ $# -gt 1 || ( $# -eq 1 && $1 != --update ) ]]; then
    printf 'Использование: ./start.sh [--update]\n' >&2
    exit 2
fi
if [[ $(uname -s) != Linux || ! -r /etc/os-release ]]; then
    printf 'Этот установщик запускается на Debian VPS, а не на Mac.\n' >&2
    exit 2
fi
# /etc/os-release is an operating-system file, not user-supplied configuration.
. /etc/os-release
if [[ ${ID:-} != debian || ( ${VERSION_ID:-} != 12 && ${VERSION_ID:-} != 13 ) ]]; then
    printf 'Поддерживаются Debian 12 и Debian 13. Обнаружено: %s\n' "${PRETTY_NAME:-unknown}" >&2
    exit 2
fi
if [[ $(id -u) -ne 0 ]]; then
    if ! command -v sudo >/dev/null 2>&1; then
        printf 'Запусти от root: su -; затем перейди в проект и выполни ./start.sh\n' >&2
        exit 2
    fi
    exec sudo --preserve-env=VPN_HOST,VPN_PORT,REALITY_SNI,VPN_NAME bash "$SCRIPT_DIR/start.sh" "$@"
fi
if [[ ! -d /run/systemd/system ]] || ! command -v systemctl >/dev/null 2>&1; then
    printf 'Нужен VPS с запущенным systemd. Контейнер без systemd не подходит.\n' >&2
    exit 2
fi
case $(dpkg --print-architecture) in
    amd64|arm64) ;;
    *) printf 'Поддерживаются архитектуры amd64 и arm64.\n' >&2; exit 2 ;;
esac
trap 'rc=$?; printf "\nУстановка прервана (код %s, строка %s). Подробности — выше.\n" "$rc" "$LINENO" >&2; exit "$rc"' ERR

if command -v flock >/dev/null 2>&1; then
    exec 9>/run/happ-vpn-install.lock
    flock -n 9 || { printf 'Уже работает другой установщик.\n' >&2; exit 1; }
fi

packages=(ca-certificates curl python3 openssl iproute2 qrencode util-linux)
missing=()
for package in "${packages[@]}"; do
    if ! dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q '^install ok installed$'; then
        missing+=("$package")
    fi
done
if [[ ${#missing[@]} -gt 0 ]]; then
    printf '\n[1/5] Устанавливаю системные пакеты…\n'
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${missing[@]}"
else
    printf '\n[1/5] Системные пакеты уже установлены.\n'
fi
python3 "$SCRIPT_DIR/vpn.py" install --bundle "$SCRIPT_DIR" "$@"

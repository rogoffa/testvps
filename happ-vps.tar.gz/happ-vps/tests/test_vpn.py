import base64
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, unquote, urlsplit
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("vpn", ROOT / "vpn.py")
vpn = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = vpn
spec.loader.exec_module(vpn)
RELEASE = json.loads((ROOT / "release.json").read_text())
PRIVATE = base64.urlsafe_b64encode(bytes(range(32))).decode().rstrip("=")
PUBLIC = base64.urlsafe_b64encode(bytes(range(32, 64))).decode().rstrip("=")


def fixture_state():
    return {
        "schema": 1, "host": "8.8.8.8", "port": 443, "sni": "www.cloudflare.com",
        "private_key": PRIVATE, "public_key": PUBLIC, "short_id": "0123456789abcdef",
        "clients": [{"name": "Мой ноут & телефон", "id": "50e9119c-1234-4eb6-a192-f661b58a1181"}],
        "release": copy.deepcopy(RELEASE),
    }


class ConfigurationTests(unittest.TestCase):
    def test_happ_link_round_trip_and_secret_separation(self):
        state = fixture_state()
        uri = vpn.client_uri(state, state["clients"][0])
        parsed = urlsplit(uri)
        query = parse_qs(parsed.query)
        self.assertEqual(parsed.scheme, "vless")
        self.assertEqual(parsed.hostname, state["host"])
        self.assertEqual(parsed.port, 443)
        self.assertEqual(parsed.username, state["clients"][0]["id"])
        self.assertEqual(unquote(parsed.fragment), state["clients"][0]["name"])
        for key, value in {"security": "reality", "flow": "xtls-rprx-vision", "type": "tcp", "sni": state["sni"], "pbk": PUBLIC, "sid": state["short_id"], "fp": "chrome", "spx": "/"}.items():
            self.assertEqual(query[key], [value])
        self.assertNotIn(PRIVATE, uri)

    def test_server_and_probe_use_corresponding_keys(self):
        state = fixture_state()
        server = vpn.server_config(state)
        probe = vpn.probe_config(state, 12345)
        inbound = server["inbounds"][0]
        outbound = probe["outbounds"][0]
        self.assertEqual(inbound["streamSettings"]["realitySettings"]["privateKey"], PRIVATE)
        self.assertEqual(outbound["streamSettings"]["realitySettings"]["password"], PUBLIC)
        self.assertEqual(inbound["settings"]["users"][0]["id"], outbound["settings"]["vnext"][0]["users"][0]["id"])
        self.assertEqual(probe["inbounds"][0]["listen"], "127.0.0.1")
        self.assertNotIn(PRIVATE, json.dumps(probe))

    def test_modern_and_legacy_keypair_output(self):
        for output in [f"PrivateKey: {PRIVATE}\nPassword (PublicKey): {PUBLIC}\nHash32: ignored\n", f"Private key: {PRIVATE}\nPublic key: {PUBLIC}\n"]:
            self.assertEqual(vpn.parse_keypair(output), (PRIVATE, PUBLIC))
        with self.assertRaises(RuntimeError):
            vpn.parse_keypair("unexpected output")

    def test_rejects_invalid_configuration(self):
        for key, value in [("short_id", "abc"), ("private_key", "bad"), ("port", 65536), ("host", "127.0.0.1"), ("sni", "8.8.8.8"), ("schema", 999), ("clients", [])]:
            with self.subTest(key=key):
                state = fixture_state()
                state[key] = value
                with self.assertRaises((ValueError, KeyError)):
                    vpn.validate_state(state)
        for host in ["https://example.com", "a.com:443", "999.0.1.1", "a..com", "localhost", "::1"]:
            with self.subTest(host=host), self.assertRaises(ValueError):
                vpn.hostname(host)

    def test_duplicate_client_or_control_characters_rejected(self):
        state = fixture_state()
        state["clients"].append(copy.deepcopy(state["clients"][0]))
        with self.assertRaises(ValueError):
            vpn.validate_state(state)
        with self.assertRaises(ValueError):
            vpn.client_name("laptop\nsecond line")


class ArtifactTests(unittest.TestCase):
    def test_pinned_release_has_both_architectures(self):
        vpn.validate_release(RELEASE)

    def test_hash_mismatch_prevents_install(self):
        with tempfile.TemporaryDirectory() as temporary:
            p = Path(temporary) / "download.zip"
            p.write_bytes(b"downloaded archive")
            with self.assertRaises(RuntimeError):
                vpn.verify_archive(p, "0" * 64)
            vpn.verify_archive(p, hashlib.sha256(p.read_bytes()).hexdigest())

    def test_archive_uses_only_known_paths(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive = root / "release.zip"
            with zipfile.ZipFile(archive, "w") as bundle:
                bundle.writestr("../../escape.txt", "must not be extracted")
                for name in ["xray", "geoip.dat", "geosite.dat"]:
                    bundle.writestr(name, "fixture")
            output = root / "output"
            output.mkdir()
            vpn.extract_assets(archive, output)
            self.assertEqual({x.name for x in output.iterdir()}, {"xray", "geoip.dat", "geosite.dat"})
            self.assertEqual(stat.S_IMODE((output / "xray").stat().st_mode), 0o755)
            self.assertFalse((root / "escape.txt").exists())

    def test_archive_rejects_executable_symlink(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive = root / "release.zip"
            with zipfile.ZipFile(archive, "w") as bundle:
                link = zipfile.ZipInfo("xray")
                link.create_system = 3
                link.external_attr = (stat.S_IFLNK | 0o777) << 16
                bundle.writestr(link, "/bin/sh")
            with self.assertRaises(RuntimeError):
                vpn.extract_assets(archive, root)

    def test_latest_release_requires_official_digest(self):
        response = {"tag_name": "v99.1.2", "prerelease": False, "draft": False, "assets": [{"name": a["name"]} for a in RELEASE["assets"].values()]}
        with patch.object(vpn, "fetch_json", return_value=response), self.assertRaises(RuntimeError):
            vpn.latest_release()

    def test_transaction_restores_files_permissions_and_absent_paths(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            existing = root / "existing"
            existing.write_bytes(b"working configuration")
            existing.chmod(0o640)
            new = root / "new"
            transaction = vpn.FileTransaction(root / "backup")
            transaction.put(existing, b"broken configuration")
            transaction.put(new, b"new file")
            transaction.rollback()
            self.assertEqual(existing.read_bytes(), b"working configuration")
            self.assertEqual(stat.S_IMODE(existing.stat().st_mode), 0o640)
            self.assertFalse(new.exists())


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.paths = vpn.Paths(Path(self.temporary.name) / "server")
        self.running = False
        self.enabled = False
        self.downloads = 0
        self.fail_restart_once = False
        self.patches = [
            patch("sys.stdout", new_callable=io.StringIO),
            patch.object(vpn, "run", side_effect=self.fake_run),
            patch.object(vpn, "download_release", side_effect=self.fake_download),
            patch.object(vpn, "discover_host", return_value="8.8.8.8"),
            patch.object(vpn, "choose_target", return_value="www.cloudflare.com"),
            patch.object(vpn, "ensure_user", return_value=os.getgid()),
            patch.object(vpn, "doctor"),
            patch.object(vpn, "configure_firewall"),
            patch.object(vpn, "show_profiles"),
            patch.object(vpn.os, "chown"),
            patch.object(vpn.os, "fchown"),
            patch.object(vpn.time, "sleep"),
            patch.dict(os.environ, {"VPN_HOST": "", "VPN_PORT": "", "REALITY_SNI": "", "VPN_NAME": ""}),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)

    def fake_download(self, release, arch, directory):
        self.downloads += 1
        for name in ["xray", "geoip.dat", "geosite.dat"]:
            p = Path(directory) / name
            p.write_bytes((name + release["version"]).encode())
            p.chmod(0o755 if name == "xray" else 0o644)

    def fake_run(self, args, *, check=True, **kwargs):
        args = [str(a) for a in args]
        code, output = 0, ""
        if args[0] == "dpkg":
            output = "amd64\n"
        elif args[0] == "ss":
            output = ""
        elif args[0] == "systemctl":
            if args[1] == "is-active":
                code = 0 if self.running else 3
            elif args[1] == "is-enabled":
                code = 0 if self.enabled else 1
            elif args[1] == "enable":
                self.enabled = True
            elif args[1] == "disable":
                self.enabled = False
            elif args[1] == "restart":
                if self.fail_restart_once:
                    self.fail_restart_once = False
                    raise RuntimeError("fixture activation failure")
                self.running = True
            elif args[1] == "stop":
                self.running = False
        elif args[1:] == ["x25519"]:
            output = f"PrivateKey: {PRIVATE}\nPassword (PublicKey): {PUBLIC}\nHash32: unused\n"
        return subprocess.CompletedProcess(args, code, output, "")

    def test_first_install_and_repeat_keep_credentials_and_permissions(self):
        vpn.install(self.paths, ROOT)
        state = vpn.load_state(self.paths)
        config = self.paths.config.read_bytes()
        vpn.install(self.paths, ROOT)
        self.assertEqual(vpn.load_state(self.paths), state)
        self.assertEqual(self.paths.config.read_bytes(), config)
        self.assertEqual(self.downloads, 1)
        self.assertTrue(self.running and self.enabled)
        self.assertEqual(stat.S_IMODE(self.paths.lib.stat().st_mode), 0o755)
        self.assertEqual(stat.S_IMODE(self.paths.config.stat().st_mode), 0o640)
        self.assertEqual(stat.S_IMODE(self.paths.state.stat().st_mode), 0o600)
        self.assertIn(state["clients"][0]["id"], (self.paths.etc / "client.txt").read_text())

    def test_failed_service_activation_rolls_back_previous_install(self):
        vpn.install(self.paths, ROOT)
        original = {p: p.read_bytes() for p in [self.paths.state, self.paths.config, self.paths.binary, self.paths.unit]}
        self.fail_restart_once = True
        with self.assertRaises(RuntimeError):
            vpn.install(self.paths, ROOT)
        for p, data in original.items():
            self.assertEqual(p.read_bytes(), data)
        self.assertTrue(self.running)

    def test_unmanaged_install_not_overwritten(self):
        self.paths.config.parent.mkdir(parents=True)
        self.paths.config.write_text("external configuration")
        with self.assertRaises(RuntimeError):
            vpn.install(self.paths, ROOT)
        self.assertEqual(self.paths.config.read_text(), "external configuration")

    def test_update_validation_failure_keeps_previous_service(self):
        vpn.install(self.paths, ROOT)
        original = self.paths.state.read_bytes(), self.paths.binary.read_bytes()
        release = copy.deepcopy(RELEASE)
        release["version"] = "v99.1.2"
        with patch.object(vpn, "latest_release", return_value=release), patch.object(vpn, "check_config", side_effect=RuntimeError("bad candidate")):
            with self.assertRaises(RuntimeError):
                vpn.install(self.paths, ROOT, update=True)
        self.assertEqual((self.paths.state.read_bytes(), self.paths.binary.read_bytes()), original)
        self.assertTrue(self.running)

    def test_tunnel_test_failure_is_reported_without_claiming_success(self):
        with patch.object(vpn, "doctor", side_effect=RuntimeError("fixture tunnel failure")), patch("sys.stderr", new_callable=io.StringIO):
            with self.assertRaisesRegex(RuntimeError, "fixture tunnel failure"):
                vpn.install(self.paths, ROOT)
        self.assertTrue(self.running)
        self.assertTrue(self.paths.state.is_file())
        self.assertNotIn("Сервер готов:", sys.stdout.getvalue())


class PortTests(unittest.TestCase):
    def test_foreign_listener_rejected(self):
        def result(args, **kwargs):
            return subprocess.CompletedProcess(args, 0, 'LISTEN users:(("nginx",pid=10,fd=7))' if args[0] == "ss" else "20\n", "")
        with patch.object(vpn, "run", side_effect=result), self.assertRaises(RuntimeError):
            vpn.check_port(443)

    def test_own_listener_allowed_on_repeat_install(self):
        def result(args, **kwargs):
            return subprocess.CompletedProcess(args, 0, 'LISTEN users:(("xray",pid=20,fd=7))' if args[0] == "ss" else "20\n", "")
        with patch.object(vpn, "run", side_effect=result):
            vpn.check_port(443)


if __name__ == "__main__":
    unittest.main()

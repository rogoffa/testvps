#!/usr/bin/env python3
"""Debian installer and local administrator CLI; Python standard library only."""
from __future__ import annotations

import argparse
import base64
import copy
from dataclasses import dataclass
from datetime import datetime, timezone
import fcntl
import grp
import hashlib
import http.client
import ipaddress
import json
import os
from pathlib import Path
import pwd
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import time
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen
import uuid
import zipfile

SERVICE = "happ-vpn.service"
USER = "happ-vpn"
REPO = "https://github.com/XTLS/Xray-core"
TARGETS = ["www.cloudflare.com", "www.wikipedia.org", "www.kernel.org"]


@dataclass(frozen=True)
class Paths:
    root: Path = Path("/")

    @property
    def etc(self): return self.root / "etc/happ-vpn"
    @property
    def lib(self): return self.root / "usr/local/lib/happ-vpn"
    @property
    def state(self): return self.etc / "state.json"
    @property
    def config(self): return self.etc / "config.json"
    @property
    def binary(self): return self.lib / "xray"
    @property
    def unit(self): return self.root / "etc/systemd/system" / SERVICE
    @property
    def wrapper(self): return self.root / "usr/local/bin/happ-vpn"
    @property
    def backups(self): return self.root / "var/lib/happ-vpn/backups"


def run(args, *, check=True, **kwargs):
    result = subprocess.run([str(x) for x in args], text=True, capture_output=True, **kwargs)
    if check and result.returncode:
        detail = (result.stderr or result.stdout).strip()[-1600:]
        raise RuntimeError(f"Не выполнено {args[0]}: {detail}")
    return result


def atomic_write(path, content, mode=0o600, gid=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".new-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            if gid is not None:
                os.fchown(stream.fileno(), 0, gid)
            stream.write(content.encode() if isinstance(content, str) else content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


class FileTransaction:
    """Keep the previous files and modes, including when service activation fails."""
    def __init__(self, backup_dir):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.before = {}

    def put(self, path, content, mode=0o600, gid=None):
        path = Path(path)
        if path not in self.before:
            if path.is_symlink():
                raise RuntimeError(f"Управляемый файл неожиданно является ссылкой: {path}")
            if path.exists():
                metadata = path.stat()
                backup = self.backup_dir / str(len(self.before))
                backup.write_bytes(path.read_bytes())
                backup.chmod(0o600)
                self.before[path] = (backup, metadata.st_mode & 0o777, metadata.st_gid)
            else:
                self.before[path] = None
        atomic_write(path, content, mode, gid)

    def rollback(self):
        for path, previous in reversed(list(self.before.items())):
            if previous is None:
                path.unlink(missing_ok=True)
            else:
                backup, mode, gid = previous
                atomic_write(path, backup.read_bytes(), mode, gid if os.geteuid() == 0 else None)


def hostname(value):
    value = str(value).strip().lower().rstrip(".")
    if not value or len(value) > 253:
        raise ValueError("Не задан корректный адрес сервера / SNI")
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        if re.fullmatch(r"[0-9.]+", value):
            raise ValueError("Некорректный IPv4")
        if not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", p) for p in value.split(".")) or "." not in value:
            raise ValueError("Нужен IPv4 или домен латиницей, без https:// и номера порта")
        return value
    if address.version != 4 or not address.is_global:
        raise ValueError("Нужен публичный IPv4; IPv6-only и частные адреса эта сборка не поддерживает")
    return str(address)


def port_number(value):
    port = int(value)
    if not 1 <= port <= 65535:
        raise ValueError("Порт должен быть от 1 до 65535")
    return port


def client_name(value):
    value = str(value).strip()
    if not 1 <= len(value) <= 64 or any(ord(c) < 32 for c in value):
        raise ValueError("Имя профиля: от 1 до 64 символов, без переводов строки")
    return value


def key32(value):
    if not re.fullmatch(r"[A-Za-z0-9_-]{43}", value):
        raise ValueError("Некорректный ключ REALITY")
    if len(base64.urlsafe_b64decode(value + "=")) != 32:
        raise ValueError("Некорректная длина ключа REALITY")


def parse_keypair(output):
    private = re.search(r"(?im)^Private\s*Key\s*:\s*([A-Za-z0-9_-]+)", output)
    public = re.search(r"(?im)^(?:Password(?:\s*\(PublicKey\))?|Public\s*Key)\s*:\s*([A-Za-z0-9_-]+)", output)
    if not private or not public:
        raise RuntimeError("Xray не вернул ожидаемую пару ключей X25519")
    private, public = private.group(1), public.group(1)
    key32(private)
    key32(public)
    return private, public


def validate_state(state):
    if state.get("schema") != 1:
        raise ValueError("Неизвестная версия state.json; файл не будет перезаписан")
    hostname(state["host"])
    port_number(state["port"])
    sni = hostname(state["sni"])
    try:
        ipaddress.ip_address(sni)
    except ValueError:
        pass
    else:
        raise ValueError("В SNI требуется доменное имя")
    key32(state["private_key"])
    key32(state["public_key"])
    if not re.fullmatch(r"[0-9a-f]{16}", state["short_id"]):
        raise ValueError("Некорректный short_id")
    if not state["clients"]:
        raise ValueError("Должен остаться хотя бы один клиент")
    identifiers, names = set(), set()
    for client in state["clients"]:
        identifier = str(uuid.UUID(client["id"]))
        name = client_name(client["name"])
        if identifier in identifiers or name in names:
            raise ValueError("Повторяющееся имя / UUID клиента")
        identifiers.add(identifier)
        names.add(name)
    validate_release(state["release"])


def server_config(state):
    validate_state(state)
    return {
        "log": {"access": "none", "loglevel": "warning"},
        "inbounds": [{
            "tag": "vless-reality", "listen": "0.0.0.0", "port": state["port"], "protocol": "vless",
            "settings": {"users": [{"id": c["id"], "flow": "xtls-rprx-vision"} for c in state["clients"]], "decryption": "none"},
            "streamSettings": {"network": "raw", "security": "reality", "realitySettings": {
                "show": False, "target": state["sni"] + ":443", "xver": 0,
                "serverNames": [state["sni"]], "privateKey": state["private_key"], "shortIds": [state["short_id"]],
            }},
        }],
        "outbounds": [{"protocol": "freedom", "tag": "direct", "settings": {
            "domainStrategy": "UseIPv4", "finalRules": [{"action": "block", "ip": ["geoip:private"]}],
        }}],
    }


def client_uri(state, client):
    query = urlencode({
        "encryption": "none", "security": "reality", "type": "tcp", "flow": "xtls-rprx-vision",
        "sni": state["sni"], "fp": "chrome", "pbk": state["public_key"], "sid": state["short_id"], "spx": "/",
    })
    return f"vless://{client['id']}@{state['host']}:{state['port']}?{query}#{quote(client['name'], safe='')}"


def probe_config(state, socks_port):
    return {
        "log": {"loglevel": "warning"},
        "inbounds": [{"listen": "127.0.0.1", "port": socks_port, "protocol": "socks", "settings": {"auth": "noauth", "udp": False}}],
        "outbounds": [{"protocol": "vless", "settings": {"vnext": [{
            "address": "127.0.0.1", "port": state["port"], "users": [{
                "id": state["clients"][0]["id"], "encryption": "none", "flow": "xtls-rprx-vision",
            }],
        }]}, "streamSettings": {"network": "raw", "security": "reality", "realitySettings": {
            "serverName": state["sni"], "fingerprint": "chrome", "password": state["public_key"], "shortId": state["short_id"], "spiderX": "/",
        }}}],
    }


def fetch_json(url):
    request = Request(url, headers={"User-Agent": "happ-vps/1", "Accept": "application/vnd.github+json"})
    with urlopen(request, timeout=25) as response:
        return json.load(response)


def validate_release(release):
    if not re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+", release["version"]):
        raise ValueError("Некорректный номер релиза")
    for arch, expected in {"amd64": "Xray-linux-64.zip", "arm64": "Xray-linux-arm64-v8a.zip"}.items():
        asset = release["assets"][arch]
        if asset["name"] != expected or not re.fullmatch(r"[0-9a-f]{64}", asset["sha256"]):
            raise ValueError("В описании релиза нет ожидаемого архива или SHA-256")


def latest_release():
    data = fetch_json("https://api.github.com/repos/XTLS/Xray-core/releases/latest")
    if data.get("prerelease") or data.get("draft"):
        raise RuntimeError("GitHub вернул предварительный релиз; обновление остановлено")
    names = {"amd64": "Xray-linux-64.zip", "arm64": "Xray-linux-arm64-v8a.zip"}
    result = {"version": data["tag_name"], "assets": {}}
    for arch, name in names.items():
        item = next((a for a in data["assets"] if a["name"] == name), None)
        digest = item.get("digest", "") if item else ""
        if not digest.startswith("sha256:"):
            raise RuntimeError(f"GitHub не опубликовал SHA-256 для {name}; обновление остановлено")
        result["assets"][arch] = {"name": name, "sha256": digest.removeprefix("sha256:")}
    validate_release(result)
    return result


def verify_archive(archive, expected):
    hasher = hashlib.sha256()
    with Path(archive).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            hasher.update(chunk)
    digest = hasher.hexdigest()
    if not secrets.compare_digest(digest, expected):
        raise RuntimeError("SHA-256 архива Xray не совпал. Архив не будет установлен")


def extract_assets(archive, directory):
    # Explicit names avoid Zip Slip; no archive-provided executable path is used.
    with zipfile.ZipFile(archive) as bundle:
        for name in ["xray", "geoip.dat", "geosite.dat"]:
            entries = [i for i in bundle.infolist() if i.filename == name]
            if len(entries) != 1 or entries[0].file_size > 150 * 1024 * 1024 or entries[0].is_dir():
                raise RuntimeError(f"В архиве нет единственного ожидаемого файла {name}")
            if (entries[0].external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError("Архив Xray содержит символическую ссылку")
            path = Path(directory) / name
            with bundle.open(entries[0]) as source, path.open("wb") as target:
                shutil.copyfileobj(source, target)
            path.chmod(0o755 if name == "xray" else 0o644)


def download_release(release, arch, directory):
    validate_release(release)
    asset = release["assets"][arch]
    url = f"{REPO}/releases/download/{release['version']}/{asset['name']}"
    archive = Path(directory) / "xray.zip"
    print(f"[2/5] Скачиваю Xray {release['version']} ({arch}) и проверяю SHA-256…", flush=True)
    request = Request(url, headers={"User-Agent": "happ-vps/1"})
    with urlopen(request, timeout=30) as response, archive.open("wb") as target:
        total = 0
        while chunk := response.read(1024 * 1024):
            total += len(chunk)
            if total > 200 * 1024 * 1024:
                raise RuntimeError("Архив Xray неожиданно большой")
            target.write(chunk)
    verify_archive(archive, asset["sha256"])
    extract_assets(archive, directory)


def discover_host():
    configured = os.environ.get("VPN_HOST", "").strip()
    if configured:
        return hostname(configured)
    for endpoint in ["https://api.ipify.org", "https://ipv4.icanhazip.com"]:
        try:
            with urlopen(Request(endpoint, headers={"User-Agent": "happ-vps/1"}), timeout=8) as response:
                value = response.read(256).decode().strip()
            address = ipaddress.ip_address(value)
            if address.version == 4:
                return hostname(value)
        except Exception:
            continue
    raise RuntimeError("Не удалось определить публичный IPv4. Запустите: VPN_HOST=ВАШ_IP ./start.sh")


def probe_target(sni):
    sni = hostname(sni)
    try:
        ipaddress.ip_address(sni)
    except ValueError:
        pass
    else:
        raise ValueError("REALITY_SNI должен быть доменом, а не IP")
    context = ssl.create_default_context()
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(["h2"])
    with socket.create_connection((sni, 443), timeout=5) as raw:
        with context.wrap_socket(raw, server_hostname=sni) as tls:
            if tls.version() != "TLSv1.3" or tls.selected_alpn_protocol() != "h2":
                raise RuntimeError("Сайт не согласовал TLS 1.3 и HTTP/2")
    connection = http.client.HTTPSConnection(sni, timeout=5)
    try:
        connection.request("HEAD", "/", headers={"User-Agent": "Mozilla/5.0"})
        response = connection.getresponse()
        if response.status in {301, 302, 303, 307, 308}:
            raise RuntimeError("Главная страница сайта перенаправляет на другой адрес")
        response.close()
    finally:
        connection.close()
    return sni


def choose_target():
    configured = os.environ.get("REALITY_SNI", "").strip()
    candidates = [configured] if configured else secrets.SystemRandom().sample(TARGETS, len(TARGETS))
    for candidate in candidates:
        print(f"Проверяю сайт для REALITY: {candidate}…", flush=True)
        try:
            return probe_target(candidate)
        except Exception as error:
            print(f"  Не подошёл: {error}", flush=True)
    raise RuntimeError("Не найден доступный сайт с TLS 1.3 и HTTP/2. Задайте REALITY_SNI=домен и повторите")


def load_state(paths):
    if not paths.state.is_file():
        raise RuntimeError("Установка не найдена. Сначала запустите ./start.sh")
    state = json.loads(paths.state.read_text())
    validate_state(state)
    return state


def ensure_user():
    try:
        account = pwd.getpwnam(USER)
        if account.pw_uid == 0:
            raise RuntimeError("Пользователь службы неожиданно имеет UID 0")
    except KeyError:
        run(["useradd", "--system", "--user-group", "--home-dir", "/nonexistent", "--shell", "/usr/sbin/nologin", USER])
    return grp.getgrnam(USER).gr_gid


def active():
    return run(["systemctl", "is-active", "--quiet", SERVICE], check=False).returncode == 0


def check_port(port):
    listeners = run(["ss", "-H", "-ltnp", "sport", "=", f":{port}"]).stdout.strip()
    if not listeners:
        return
    pid = run(["systemctl", "show", "-p", "MainPID", "--value", SERVICE], check=False).stdout.strip()
    owners = set(re.findall(r"pid=(\d+)", listeners))
    if not pid or pid == "0" or not owners or owners != {pid}:
        raise RuntimeError(f"TCP/{port} уже занят другим процессом. Освободите его или задайте VPN_PORT при первой установке")


def check_config(binary, config, asset_dir):
    environment = dict(os.environ, XRAY_LOCATION_ASSET=str(asset_dir))
    run([binary, "run", "-test", "-config", config], env=environment, timeout=25)


def backup_directory(paths):
    paths.backups.mkdir(parents=True, exist_ok=True, mode=0o700)
    return Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-"), dir=paths.backups))


def commit_install(paths, state, staged, bundle, gid):
    previous_active = active()
    previous_enabled = run(["systemctl", "is-enabled", "--quiet", SERVICE], check=False).returncode == 0
    transaction = FileTransaction(backup_directory(paths))
    paths.etc.mkdir(parents=True, exist_ok=True)
    paths.etc.chmod(0o750)
    os.chown(paths.etc, 0, gid)
    paths.lib.mkdir(parents=True, exist_ok=True, mode=0o755)
    paths.lib.chmod(0o755)
    try:
        for name in ["xray", "geoip.dat", "geosite.dat"]:
            transaction.put(paths.lib / name, (staged / name).read_bytes(), 0o755 if name == "xray" else 0o644)
        transaction.put(paths.config, json_bytes(server_config(state)), 0o640, gid)
        transaction.put(paths.state, json_bytes(state))
        transaction.put(paths.lib / "vpn.py", (bundle / "vpn.py").read_bytes(), 0o644)
        transaction.put(paths.lib / "release.json", json_bytes(state["release"]), 0o644)
        unit = (bundle / SERVICE).read_bytes()
        transaction.put(paths.lib / SERVICE, unit, 0o644)
        transaction.put(paths.unit, unit, 0o644)
        transaction.put(paths.wrapper, '#!/bin/sh\nexec /usr/bin/python3 /usr/local/lib/happ-vpn/vpn.py "$@"\n', 0o755)
        transaction.put(paths.etc / "client.txt", "\n".join(client_uri(state, c) for c in state["clients"]) + "\n")
        run(["systemctl", "daemon-reload"])
        run(["systemctl", "enable", SERVICE])
        run(["systemctl", "reset-failed", SERVICE], check=False)
        run(["systemctl", "restart", SERVICE])
        time.sleep(1)
        if not active():
            raise RuntimeError("Служба не осталась активной. Смотрите journalctl -u happ-vpn -n 50")
    except BaseException:
        transaction.rollback()
        run(["systemctl", "daemon-reload"], check=False)
        if not previous_enabled:
            run(["systemctl", "disable", SERVICE], check=False)
        run(["systemctl", "reset-failed", SERVICE], check=False)
        run(["systemctl", "restart" if previous_active else "stop", SERVICE], check=False)
        raise


def configure_firewall(port):
    if shutil.which("ufw"):
        status = run(["ufw", "status"], check=False, env=dict(os.environ, LC_ALL="C")).stdout
        if re.search(r"(?m)^Status: active", status):
            run(["ufw", "allow", f"{port}/tcp", "comment", "happ-vpn"])
            print(f"UFW: разрешён TCP/{port}.")
            return
    if shutil.which("firewall-cmd") and run(["firewall-cmd", "--state"], check=False).returncode == 0:
        run(["firewall-cmd", f"--add-port={port}/tcp"])
        run(["firewall-cmd", "--permanent", f"--add-port={port}/tcp"])
        print(f"firewalld: разрешён TCP/{port} в зоне по умолчанию.")
        return
    if shutil.which("nft"):
        rules = run(["nft", "list", "ruleset"], check=False).stdout
        if "hook input" in rules and re.search(r"\b(drop|reject)\b", rules):
            print(f"Найдены собственные nftables-правила. Проверьте разрешение входящего TCP/{port}; существующие цепочки не изменялись.")


def show_profiles(paths, name=None, qr=True):
    state = load_state(paths)
    clients = [c for c in state["clients"] if name is None or c["name"] == name]
    if not clients:
        raise ValueError("Профиль с таким именем не найден")
    for client in clients:
        link = client_uri(state, client)
        print(f"\nПрофиль: {client['name']}\n{link}\n")
        if qr and shutil.which("qrencode"):
            result = run(["qrencode", "-t", "ANSIUTF8"], check=False, input=link)
            if result.returncode == 0:
                print(result.stdout, end="")
    print(f"Ссылки также сохранены в {paths.etc / 'client.txt'} (только для root).")


def doctor(paths):
    state = load_state(paths)
    if not active():
        raise RuntimeError("Служба не активна. Выполните: journalctl -u happ-vpn -n 50")
    check_config(paths.binary, paths.config, paths.lib)
    with tempfile.TemporaryDirectory(prefix="happ-vpn-check-") as directory:
        temporary = Path(directory)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            socks_port = sock.getsockname()[1]
        config = temporary / "client.json"
        atomic_write(config, json_bytes(probe_config(state, socks_port)))
        log = temporary / "client.log"
        with log.open("wb") as stream:
            client = subprocess.Popen(
                [str(paths.binary), "run", "-config", str(config)],
                stdout=stream, stderr=stream,
                env=dict(os.environ, XRAY_LOCATION_ASSET=str(paths.lib)),
            )
            try:
                for _ in range(30):
                    if client.poll() is not None:
                        raise RuntimeError("Проверочный клиент Xray завершился до подключения")
                    try:
                        with socket.create_connection(("127.0.0.1", socks_port), timeout=0.2):
                            break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError("Проверочный SOCKS-клиент не открыл локальный порт")
                result = run([
                    "curl", "--fail", "--silent", "--show-error", "--noproxy", "",
                    "--socks5-hostname", f"127.0.0.1:{socks_port}",
                    "--connect-timeout", "8", "--max-time", "20", "https://api.ipify.org",
                ], check=False)
                if result.returncode:
                    raise RuntimeError("Проверка HTTPS через туннель не прошла: " + result.stderr.strip())
                address = ipaddress.ip_address(result.stdout.strip())
                print(f"OK: служба, конфигурация, REALITY-авторизация и HTTPS через туннель. Выходной IP: {address}")
                print(f"Входящий доступ к {state['host']}:{state['port']} из вашей сети проверяется в Happ; локальный тест не проверяет firewall хостинга.")
            finally:
                client.terminate()
                try:
                    client.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    client.kill()
                    client.wait()


def install(paths, bundle, update=False):
    bundle = Path(bundle).resolve()
    previous = load_state(paths) if paths.state.exists() else None
    if previous is None and (paths.config.exists() or paths.unit.exists() or paths.binary.exists()):
        raise RuntimeError("Найдены файлы happ-vpn без state.json. Чужая / неполная установка не будет перезаписана")
    if previous and any(os.environ.get(k) for k in ["VPN_HOST", "VPN_PORT", "REALITY_SNI", "VPN_NAME"]):
        raise RuntimeError("Настройки существующего сервера меняются через happ-vpn configure / add. Ключи при повторном ./start.sh сохраняются")
    arch = run(["dpkg", "--print-architecture"]).stdout.strip()
    if arch not in {"amd64", "arm64"}:
        raise ValueError("Поддерживаются только amd64 и arm64")
    release = latest_release() if update else (previous["release"] if previous else json.loads((bundle / "release.json").read_text()))
    validate_release(release)
    port = previous["port"] if previous else port_number(os.environ.get("VPN_PORT") or "443")
    check_port(port)
    gid = ensure_user()
    with tempfile.TemporaryDirectory(prefix="happ-vpn-install-") as directory:
        staged = Path(directory)
        reusable = previous and previous["release"] == release and all((paths.lib / n).is_file() for n in ["xray", "geoip.dat", "geosite.dat"])
        if reusable:
            print(f"[2/5] Использую установленный Xray {release['version']}; ключи сохраняются.", flush=True)
            for name in ["xray", "geoip.dat", "geosite.dat"]:
                shutil.copy2(paths.lib / name, staged / name)
        else:
            download_release(release, arch, staged)
        state = copy.deepcopy(previous)
        if state is None:
            print("[3/5] Определяю адрес, проверяю REALITY и создаю индивидуальные ключи…", flush=True)
            host = discover_host()
            sni = choose_target()
            private, public = parse_keypair(run([staged / "xray", "x25519"]).stdout)
            state = {
                "schema": 1, "host": host, "port": port, "sni": sni,
                "private_key": private, "public_key": public, "short_id": secrets.token_hex(8),
                "clients": [{"name": client_name(os.environ.get("VPN_NAME") or "Личный VPN"), "id": str(uuid.uuid4())}],
            }
        else:
            print("[3/5] Проверяю сохранённую конфигурацию…", flush=True)
        state["release"] = release
        candidate = staged / "config.json"
        atomic_write(candidate, json_bytes(server_config(state)))
        check_config(staged / "xray", candidate, staged)
        print("[4/5] Устанавливаю и запускаю службу systemd…", flush=True)
        commit_install(paths, state, staged, bundle, gid)
    configure_firewall(port)
    print("[5/5] Проверяю соединение через установленный сервер…", flush=True)
    try:
        doctor(paths)
    except Exception:
        print("Служба установлена, но проверка туннеля не завершилась успешно. Ссылки ниже; диагностика: sudo happ-vpn doctor", file=sys.stderr)
        show_profiles(paths)
        raise
    print(f"\nСервер готов: {state['host']}:{state['port']}, SNI {state['sni']}, Xray {release['version']}")
    print("В Happ импортируйте ссылку из буфера обмена или отсканируйте QR.")
    show_profiles(paths)
    print(f"\nВ панели VPS должен быть разрешён входящий TCP/{port}. SSH и маршрутизация сервера не менялись.")
    print("Служба работает после выхода из SSH и перезапуска VPS. Telegram-бот можно запускать отдельной службой.")


def change_state(paths, state):
    validate_state(state)
    gid = grp.getgrnam(USER).gr_gid
    transaction = FileTransaction(backup_directory(paths))
    with tempfile.TemporaryDirectory(prefix="happ-vpn-config-") as temporary:
        candidate = Path(temporary) / "config.json"
        atomic_write(candidate, json_bytes(server_config(state)))
        check_config(paths.binary, candidate, paths.lib)
        try:
            transaction.put(paths.config, candidate.read_bytes(), 0o640, gid)
            transaction.put(paths.state, json_bytes(state))
            transaction.put(paths.etc / "client.txt", "\n".join(client_uri(state, c) for c in state["clients"]) + "\n")
            run(["systemctl", "reset-failed", SERVICE], check=False)
            run(["systemctl", "restart", SERVICE])
            time.sleep(1)
            if not active():
                raise RuntimeError("Новая конфигурация не запустилась")
        except BaseException:
            transaction.rollback()
            run(["systemctl", "reset-failed", SERVICE], check=False)
            run(["systemctl", "restart", SERVICE], check=False)
            raise


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description="Личный VLESS + REALITY сервер для Happ")
    commands = parser.add_subparsers(dest="command", required=True)
    installer = commands.add_parser("install", help="используется start.sh")
    installer.add_argument("--bundle", type=Path, required=True)
    installer.add_argument("--update", action="store_true")
    commands.add_parser("status")
    commands.add_parser("logs")
    commands.add_parser("restart")
    commands.add_parser("doctor")
    commands.add_parser("help")
    commands.add_parser("update")
    info = commands.add_parser("info")
    info.add_argument("name", nargs="?")
    info.add_argument("--no-qr", action="store_true")
    add = commands.add_parser("add")
    add.add_argument("name")
    remove = commands.add_parser("remove")
    remove.add_argument("name")
    configure = commands.add_parser("configure")
    configure.add_argument("--sni")
    configure.add_argument("--host")
    configure.add_argument("--port", type=port_number)
    args = parser.parse_args()
    if args.command == "help":
        parser.print_help()
        print("\ninfo [имя]     ссылка и QR\nadd имя        новый клиент\nremove имя     отозвать клиента\nconfigure --sni домен / --host IPv4 / --port число\nstatus / logs / restart / doctor / update")
        return
    if sys.platform != "linux" or os.geteuid() != 0:
        parser.error("Эта команда выполняется от root на Debian VPS")
    paths = Paths()
    if args.command == "logs":
        os.execvp("journalctl", ["journalctl", "-u", SERVICE, "-n", "100", "-f"])
    with Path("/run/happ-vpn-management.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Уже выполняется другая операция happ-vpn")
        if args.command == "install":
            install(paths, args.bundle, args.update)
        elif args.command == "update":
            install(paths, paths.lib, update=True)
        elif args.command == "info":
            show_profiles(paths, args.name, not args.no_qr)
        elif args.command == "doctor":
            doctor(paths)
        elif args.command == "status":
            os.execvp("systemctl", ["systemctl", "status", "--no-pager", SERVICE])
        elif args.command == "restart":
            run(["systemctl", "reset-failed", SERVICE], check=False)
            run(["systemctl", "restart", SERVICE])
            doctor(paths)
        else:
            state = load_state(paths)
            if args.command == "add":
                name = client_name(args.name)
                if any(c["name"] == name for c in state["clients"]):
                    raise ValueError("Клиент с таким именем уже есть")
                state["clients"].append({"name": name, "id": str(uuid.uuid4())})
            elif args.command == "remove":
                if not any(c["name"] == args.name for c in state["clients"]):
                    raise ValueError("Клиент не найден")
                state["clients"] = [c for c in state["clients"] if c["name"] != args.name]
            elif args.command == "configure":
                if not (args.sni or args.host or args.port):
                    raise ValueError("Укажите --sni, --host или --port")
                if args.sni:
                    state["sni"] = probe_target(args.sni)
                if args.host:
                    state["host"] = hostname(args.host)
                if args.port:
                    check_port(args.port)
                    state["port"] = args.port
            change_state(paths, state)
            if args.command == "configure":
                configure_firewall(state["port"])
            if args.command != "remove":
                show_profiles(paths, args.name if args.command == "add" else None)
            else:
                print("Клиент удалён. Новые соединения с его UUID не принимаются.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nОперация прервана.", file=sys.stderr)
        sys.exit(130)
    except Exception as error:
        print(f"Ошибка: {error}", file=sys.stderr)
        sys.exit(1)
